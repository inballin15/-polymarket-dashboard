# Polymarket Edge Dashboard

A read-only dashboard for researching Polymarket bets.

## What it does
- Pulls active Polymarket markets from the public Gamma API
- Attempts to pull public leaderboard data
- Scores markets by liquidity, volume, and price structure
- Shows possible markets to manually research
- Does NOT place bets or connect to your wallet

## One-click cloud setup
1. Create a free GitHub repo.
2. Upload `app.py` and `requirements.txt`.
3. Go to Streamlit Community Cloud.
4. Click "New app".
5. Select your repo and `app.py`.
6. Deploy.

## Local setup
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Important
This is not financial advice. It is a research scanner. Prediction markets are risky, and leaderboard chasing can be a bad strategy if you do not verify the actual market facts and pricing.
