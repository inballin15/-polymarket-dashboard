
import json, math, time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote_plus
import numpy as np
import pandas as pd
import requests

GAMMA_API = "https://gamma-api.polymarket.com"
STATE_PATH = Path("paper_state.json")

SETTINGS = {
    "market_limit": 300,
    "min_liquidity": 5000,
    "min_volume": 10000,
    "min_price": 0.08,
    "max_price": 0.92,
    "max_bet_pct": 0.05,
    "min_stake": 2.0,
    "max_open": 5,
    "trades_per_cycle": 3,
    "entry_quality": "Possible Bet + Watch",
    "take_profit": 0.25,
    "stop_loss": 0.25,
    "max_hold_days": 7,
}

def default_state():
    return {"cash":1000.0,"initial_bankroll":1000.0,"trades":[],"previous_prices":{},"snapshots":[],"scan_count":0,"last_run":None}

def load_state():
    return json.loads(STATE_PATH.read_text()) if STATE_PATH.exists() else default_state()

def save_state(state):
    STATE_PATH.write_text(json.dumps(state, indent=2, default=str))

def safe_get(url, params=None):
    r = requests.get(url, params=params, timeout=20)
    r.raise_for_status()
    return r.json()

def get_markets():
    data = safe_get(f"{GAMMA_API}/markets", {"active":"true","closed":"false","limit":SETTINGS["market_limit"],"order":"volume","ascending":"false"})
    return pd.DataFrame(data if isinstance(data, list) else data.get("markets", data.get("data", [])))

def parse_jsonish(v):
    if v is None: return []
    if isinstance(v, list): return v
    if isinstance(v, str):
        try: return json.loads(v)
        except Exception: return [x.strip() for x in v.split(",") if x.strip()]
    return []

def fnum(v, default=0.0):
    try:
        if v is None or v == "": return default
        return float(v)
    except Exception:
        return default

def get_prices(row):
    out = []
    for p in parse_jsonish(row.get("outcomePrices", row.get("outcome_prices", None))):
        try: out.append(float(p))
        except Exception: pass
    return out

def get_outcomes(row): return parse_jsonish(row.get("outcomes", None))
def market_url(slug): return f"https://polymarket.com/market/{slug}" if slug else "https://polymarket.com/markets"
def news_url(q): return "https://www.google.com/search?tbm=nws&q=" + quote_plus(str(q))

def category(question):
    q = str(question).lower()
    if any(w in q for w in ["ufc","nba","nfl","mlb","nhl","fight","match","soccer"]): return "Sports"
    if any(w in q for w in ["trump","iran","israel","election","war","fed","court","ceasefire"]): return "News"
    if any(w in q for w in ["token","coin","airdrop","btc","eth","sol"]): return "Crypto"
    if any(w in q for w in ["openai","anthropic","ipo","valuation","nvidia","tesla"]): return "Business/AI"
    return "General"

def flags(question, price, vol, liq, spread):
    q = str(question).lower()
    out = []
    if liq < 2500: out.append("Low liquidity")
    if vol < 5000: out.append("Low volume")
    if spread > 0.18: out.append("Wide pricing")
    if price < 0.06 or price > 0.94: out.append("Extreme price")
    if any(w in q for w in ["fdv","meme","airdrop","token","launch"]): out.append("Crypto launch risk")
    if any(w in q for w in ["ufc","nba","nfl","mlb","nhl","fight","match"]): out.append("Sports variance")
    if len(q) > 95: out.append("Complex wording")
    return out

def category_stats(state, cat):
    trades = pd.DataFrame(state["trades"])
    if trades.empty or "category" not in trades.columns: return True, 1.0
    closed = trades[(trades.status=="CLOSED") & (trades.category==cat)]
    if closed.empty: return True, 1.0
    pnl = float(closed["pnl"].sum())
    n = len(closed)
    wr = float((closed["pnl"] > 0).mean() * 100)
    if n >= 6 and pnl < -3: return False, 0.0
    if n >= 4 and pnl < 0: return True, 0.6
    if n >= 6 and pnl > 3 and wr >= 50: return True, 1.2
    return True, 1.0

def score(row, state):
    q = row.get("question", row.get("title", ""))
    slug = row.get("slug", "")
    prices = get_prices(row)
    outs = get_outcomes(row)
    if not prices: return None
    i = int(np.nanargmax(prices))
    price = float(prices[i])
    outcome = outs[i] if i < len(outs) else f"Outcome {i+1}"
    vol = fnum(row.get("volume", row.get("volumeNum", 0)))
    liq = fnum(row.get("liquidity", row.get("liquidityNum", 0)))
    vol24 = fnum(row.get("volume24hr", row.get("volume24hrClob", 0)))
    if price < SETTINGS["min_price"] or price > SETTINGS["max_price"] or vol < SETTINGS["min_volume"] or liq < SETTINGS["min_liquidity"]:
        return None
    spread = abs(sum(prices[:2]) - 1) if len(prices) >= 2 else 0.12
    cat = category(q)
    fl = flags(q, price, vol, liq, spread)
    if any(f in fl for f in ["Low liquidity","Wide pricing","Complex wording","Crypto launch risk"]): action = "Research Only"
    else: action = "Watch"
    vol_s = min(1, math.log10(max(vol,1))/7)
    liq_s = min(1, math.log10(max(liq,1))/6)
    price_s = max(0, min(1, 1-abs(price-0.5)*1.35))
    edge = max(0, min(100, 100*(0.35*vol_s+0.35*liq_s+0.30*price_s)-6.5*len(fl)))
    conf = "High" if edge >= 78 and liq >= 15000 and vol >= 25000 and len(fl) <= 1 else ("Medium" if edge >= 64 and len(fl)<=3 else "Low")
    allowed, mult = category_stats(state, cat)
    stake = 0.0
    if allowed and conf != "Low" and action != "Research Only":
        raw = state["cash"] * SETTINGS["max_bet_pct"] * mult * (1.0 if conf == "High" else 0.45)
        stake = round(min(state["cash"], max(SETTINGS["min_stake"], raw)), 2)
    key = f"{slug or q}||{outcome}"
    return {"action":action,"confidence":conf,"edge_score":round(edge,1),"price":price,"stake":stake,"question":q,"outcome":outcome,"category":cat,"trade_key":key,"open_market":market_url(slug),"news_search":news_url(q)}

def price_lookup(markets):
    lookup = {}
    for _, row in markets.iterrows():
        slug = row.get("slug", "")
        keybase = slug or row.get("question", row.get("title",""))
        prices = get_prices(row)
        outs = get_outcomes(row)
        for i,p in enumerate(prices):
            outcome = outs[i] if i < len(outs) else f"Outcome {i+1}"
            lookup[f"{keybase}||{outcome}"] = float(p)
    return lookup

def close_trade(state, t, price, reason):
    value = t["shares"] * price
    pnl = value - t["stake"]
    t.update({"status":"CLOSED","closed_at":datetime.now(timezone.utc).isoformat(),"exit_price":round(price,4),"last_price":round(price,4),"pnl":round(pnl,2),"unrealized_pnl":0.0,"close_reason":reason})
    state["cash"] += value

def update_positions(state, lookup):
    for t in state["trades"]:
        if t["status"] != "OPEN": continue
        price = lookup.get(t["trade_key"])
        if price is None: continue
        t["last_price"] = round(price,4)
        t["unrealized_pnl"] = round(t["shares"]*price-t["stake"],2)
        pct = (price-t["entry_price"])/t["entry_price"]
        age = (datetime.now(timezone.utc)-datetime.fromisoformat(t["opened_at"])).total_seconds()/86400
        if pct >= SETTINGS["take_profit"]: close_trade(state,t,price,"Take profit")
        elif pct <= -SETTINGS["stop_loss"]: close_trade(state,t,price,"Stop loss")
        elif age >= SETTINGS["max_hold_days"]: close_trade(state,t,price,"Max hold")

def open_trade(state, c):
    stake = min(c["stake"], state["cash"])
    if stake <= 0: return False
    t = {"id":len(state["trades"])+1,"status":"OPEN","opened_at":datetime.now(timezone.utc).isoformat(),"closed_at":"","question":c["question"],"outcome":c["outcome"],"trade_key":c["trade_key"],"entry_price":round(c["price"],4),"last_price":round(c["price"],4),"exit_price":None,"stake":stake,"shares":round(stake/c["price"],6),"unrealized_pnl":0.0,"pnl":0.0,"close_reason":"","action":c["action"],"confidence":c["confidence"],"edge_score":c["edge_score"],"category":c["category"],"open_market":c["open_market"],"news_search":c["news_search"]}
    state["cash"] -= stake
    state["trades"].append(t)
    return True

def performance(state):
    trades = pd.DataFrame(state["trades"])
    cash = float(state["cash"])
    if trades.empty: return cash, cash, 0, 0, 0, 0, 0, 0
    op = trades[trades.status=="OPEN"]
    cl = trades[trades.status=="CLOSED"]
    open_val = float((op["shares"]*op["last_price"]).sum()) if not op.empty else 0
    realized = float(cl["pnl"].sum()) if not cl.empty else 0
    unreal = float(op["unrealized_pnl"].sum()) if not op.empty else 0
    equity = cash + open_val
    wr = float((cl["pnl"]>0).mean()*100) if len(cl) else 0
    ret = (equity-state["initial_bankroll"])/state["initial_bankroll"]*100
    return cash,equity,realized,unreal,len(op),len(cl),wr,ret

def run():
    state = load_state()
    markets = get_markets()
    lookup = price_lookup(markets)
    update_positions(state, lookup)
    candidates = [score(row,state) for _,row in markets.iterrows()]
    candidates = [c for c in candidates if c]
    candidates.sort(key=lambda c: (0 if c["action"]!="Research Only" else 1, 0 if c["confidence"]=="High" else 1, -c["edge_score"]))
    opened = 0
    open_count = sum(1 for t in state["trades"] if t["status"]=="OPEN")
    for c in candidates:
        if opened >= SETTINGS["trades_per_cycle"] or open_count >= SETTINGS["max_open"]: break
        if c["action"]=="Research Only" or c["stake"]<=0: continue
        if any(t["status"]=="OPEN" and t["trade_key"]==c["trade_key"] for t in state["trades"]): continue
        if open_trade(state,c):
            opened += 1; open_count += 1
    cash,equity,realized,unreal,op,cl,wr,ret = performance(state)
    state["snapshots"].append({"time":datetime.now(timezone.utc).isoformat(),"cash":round(cash,2),"equity":round(equity,2),"return_pct":round(ret,2),"realized_pnl":round(realized,2),"unrealized_pnl":round(unreal,2),"open_positions":op,"closed_trades":cl,"win_rate":round(wr,1),"opened_this_cycle":opened})
    state["snapshots"] = state["snapshots"][-500:]
    state["scan_count"] = state.get("scan_count",0)+1
    state["last_run"] = datetime.now(timezone.utc).isoformat()
    save_state(state)
    print(state["snapshots"][-1])

if __name__ == "__main__":
    run()
