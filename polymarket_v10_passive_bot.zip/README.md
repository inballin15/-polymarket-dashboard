# Polymarket Passive Paper Bot V10

Paper-trading bot only. No wallet. No real money.

Upload all files to GitHub. The workflow runs `bot_runner.py` every hour and commits updates to `paper_state.json`.
Streamlit runs `app.py` as the dashboard.
