
import json
from pathlib import Path
import pandas as pd
import streamlit as st

STATE_PATH = Path("paper_state.json")

st.set_page_config(page_title="Polymarket Passive Bot V10", page_icon="🤖", layout="centered")

st.title("🤖 Polymarket Passive Bot V10")
st.caption("Paper-trading dashboard. GitHub Actions runs the bot in the background.")
st.warning("Paper trading only. No wallet. No real money.")

def load_state():
    if not STATE_PATH.exists():
        return {"cash":1000.0,"initial_bankroll":1000.0,"trades":[],"snapshots":[],"scan_count":0,"last_run":None}
    return json.loads(STATE_PATH.read_text())

state = load_state()
trades = pd.DataFrame(state.get("trades", []))
snapshots = pd.DataFrame(state.get("snapshots", []))

cash = float(state.get("cash", 1000))
initial = float(state.get("initial_bankroll", 1000))

if trades.empty:
    equity = cash
    realized = unrealized = 0.0
    open_count = closed_count = 0
    win_rate = 0.0
else:
    open_df = trades[trades["status"] == "OPEN"]
    closed_df = trades[trades["status"] == "CLOSED"]
    open_value = float((open_df["shares"] * open_df["last_price"]).sum()) if not open_df.empty else 0.0
    equity = cash + open_value
    realized = float(closed_df["pnl"].sum()) if not closed_df.empty else 0.0
    unrealized = float(open_df["unrealized_pnl"].sum()) if not open_df.empty else 0.0
    open_count = len(open_df)
    closed_count = len(closed_df)
    win_rate = float((closed_df["pnl"] > 0).mean() * 100) if closed_count else 0.0

ret = (equity - initial) / initial * 100

a,b = st.columns(2)
a.metric("Equity", f"${equity:.2f}", f"{ret:.2f}%")
b.metric("Cash", f"${cash:.2f}")
c,d = st.columns(2)
c.metric("Open", open_count)
d.metric("Closed", closed_count)
e,f = st.columns(2)
e.metric("Realized P/L", f"${realized:.2f}")
f.metric("Win Rate", f"{win_rate:.1f}%")

if state.get("last_run"):
    st.caption(f"Last background run: {state['last_run']}")
st.caption(f"Total scans: {state.get('scan_count', 0)}")

tab1, tab2, tab3, tab4 = st.tabs(["📈 Performance", "📒 Trades", "📊 Categories", "⚙️ Setup"])

with tab1:
    st.subheader("Equity curve")
    if snapshots.empty:
        st.info("No snapshots yet. GitHub Actions needs to run the bot first.")
    else:
        st.line_chart(snapshots.set_index("time")["equity"])
        st.dataframe(snapshots.tail(25), use_container_width=True)

with tab2:
    st.subheader("Trade ledger")
    if trades.empty:
        st.info("No trades yet.")
    else:
        st.dataframe(trades, use_container_width=True)
        st.download_button("Download trades CSV", trades.to_csv(index=False).encode("utf-8"), "v10_paper_trades.csv", "text/csv")

with tab3:
    st.subheader("Category performance")
    if trades.empty or "category" not in trades.columns:
        st.info("No category data yet.")
    else:
        rows = []
        for cat in sorted(trades["category"].dropna().unique()):
            closed = trades[(trades["category"] == cat) & (trades["status"] == "CLOSED")]
            open_ = trades[(trades["category"] == cat) & (trades["status"] == "OPEN")]
            pnl = float(closed["pnl"].sum()) if not closed.empty else 0.0
            wr = float((closed["pnl"] > 0).mean() * 100) if not closed.empty else 0.0
            rows.append({"Category":cat,"Open":len(open_),"Closed":len(closed),"Realized P/L":round(pnl,2),"Win Rate %":round(wr,1)})
        st.dataframe(pd.DataFrame(rows), use_container_width=True)

with tab4:
    st.subheader("How V10 works")
    st.markdown("""
    **bot_runner.py** runs automatically with GitHub Actions every hour.

    **app.py** is just the dashboard.

    You do not need to keep your iPhone open once GitHub Actions is enabled.
    """)
